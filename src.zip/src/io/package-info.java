/**
 * This pacakge act as the input and output manager for a game
 * <p>
 * these are only to be refernced
 * <p>
 * @author swalden
 * @since 0.0
 * @version 0.0
 * 
 */
package io;