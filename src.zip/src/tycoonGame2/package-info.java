/*
* Main package of the game
*@author Shawn;
*
*
**/
package tycoonGame2;